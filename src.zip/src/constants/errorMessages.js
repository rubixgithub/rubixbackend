const errorMessages = {
    EMAIL_ALREADY_EXISTS: `Email Already exists`,
    USER_IS_NOT_EXISTS: `User is not Exists`,
    TOKEN_NOT_FOUND_ERROR:`Token is missing`,
    EMAIL_NOT_EXISTS:`Email does not exists`,
    PASSWORD_NOT_MACHED:`Password not mached`,
}

export default {
    ...errorMessages
}
