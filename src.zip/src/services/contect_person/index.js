import getContecPersonService from './contectPersonService/get'
import postContecPersonService from './contectPersonService/post'
import putContecPersonService from './contectPersonService/put'
import deleteContecPersonService from './contectPersonService/delete'

export {
    getContecPersonService,
    postContecPersonService,
    putContecPersonService,
    deleteContecPersonService
}
