import getGstService from './gstService/get'
import postGstService from './gstService/post'
import putGstService from './gstService/put'
import deleteGstService from './gstService/delete'

export {
    getGstService,
    postGstService,
    putGstService,
    deleteGstService
}
