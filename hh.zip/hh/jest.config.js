module.exports = {
    testMatch: [
        '<rootDir>/test/spec/*.spec.js'
    ],
    testEnvironment: 'node'
};
