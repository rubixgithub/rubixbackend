import sequelize from '../../../models'

const create = async (exports) => sequelize.models.exports.create(exports)

export default {
    create
}
