import getGistinService from './gistinService/get'
import postGistinService from './gistinService/post'
import putGistinService from './gistinService/put'
import deleteGistinService from './gistinService/delete'

export {
    getGistinService,
    postGistinService,
    putGistinService,
    deleteGistinService
}
